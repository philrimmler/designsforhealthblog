$( "#menu-btn" ).click(function() {
  $("nav").addClass("mobile-menu");
});

